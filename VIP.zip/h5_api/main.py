#!/usr/bin/python
# -*- coding: utf-8 -*-
# @author: yuheng
# @Time : 2019/6/11 20:20 

import os
import pytest
from Common import project_path
#生成HTML测试报告

pytest.main(["--html={}".format(project_path.ReportPath),
             "--alluredir={}".format(project_path.AllurePath)
             ])

#用例名称转码
path=project_path.AllurePath
# print(path)
#读取所有该文件夹下的所有文件
files=os.listdir(path)
for f in files:
    if f.endswith('.xml'):
        # print(f)
        new_datas = ''
        with open(os.path.join(project_path.AllurePath,f), 'r',encoding='utf-8') as file:
            lines = file.readlines()
            for m in range(0, len(lines)):
                if 'test_h5Api.TestH5Api.test_api' in lines[m]:
                    j = lines[m].encode().decode("unicode_escape")
                    # print(j)
                    lines[m] = j
                    # print(lines[m])
            new_datas = lines
            # print(new_datas)
        with open(os.path.join(project_path.AllurePath,f), 'w', encoding='utf-8') as file2:
            file2.writelines(new_datas)


