#!/usr/bin/python
# -*- coding: utf-8 -*-
# @author: yuheng
# @Time : 2019/6/10 21:02 

from configparser import ConfigParser
from Common import project_path

class ReadConf:
    #读取配置文件信息
    def read_conf(self,filename,section,option):
        cf=ConfigParser()
        cf.read(filename,encoding='utf-8')
        value=cf.get(section,option)
        return value

if __name__ == '__main__':
    res=ReadConf().read_conf(project_path.ConfPath,'CASE','sheet_list')
    print (res)
